export function Components() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Components</h1>
      <p className="text-muted-foreground">
        Build the components list page here. See SPEC.md for requirements.
      </p>
    </div>
  );
}
