export function Dashboard() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <p className="text-muted-foreground">
        Build the dashboard home page here. See SPEC.md for requirements.
      </p>
    </div>
  );
}
