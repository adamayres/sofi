export function Apps() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Apps</h1>
      <p className="text-muted-foreground">
        Build the apps list page here. See SPEC.md for requirements.
      </p>
    </div>
  );
}
